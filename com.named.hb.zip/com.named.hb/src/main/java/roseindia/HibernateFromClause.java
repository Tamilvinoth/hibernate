package roseindia;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class HibernateFromClause {
private static SessionFactory sessionFactory;
private static ServiceRegistry serviceRegistry;

public static void main(String args[]) {
Session session = null;
try {
try {

sessionFactory = HibernateUtil.getSessionFactory();

} catch (Throwable th) {
System.err.println("Failed to create sessionFactory object." + th);
throw new ExceptionInInitializerError(th);
}
session = sessionFactory.openSession();
Query fromClause = session.createQuery("from Worker");
Query query = session.getNamedQuery("findViaWorkerIdHQL").setString("workerId", "102");
List workers = query.list();

for (Iterator iterator = workers.iterator(); iterator.hasNext();) {
Worker worker = (Worker) iterator.next();
System.out.println("Worker Id:" + worker.getWorkerId());
System.out.println("Worker Name:" + worker.getFirstname());
System.out.println("Worker CellPhone No."+ worker.getCellphone());
System.out.println("-----------------------------------------------------------");
}
} catch (Exception e) {
System.out.println(e.getMessage());
} finally {
session.close();
}
}
}