package roseindia;

public class Worker {

private int workerId;

private String firstname;

private int cellphone;

public Worker() {

}

public Worker(String firstname, int phone) {
this.firstname = firstname;
this.cellphone = phone;

}

public int getWorkerId() {
return workerId;
}

public void setWorkerId(int workerId) {
this.workerId = workerId;
}

public String getFirstname() {
return firstname;
}

public void setFirstname(String firstname) {
this.firstname = firstname;
}

public int getCellphone() {
return cellphone;
}

public void setCellphone(int cellphone) {
this.cellphone = cellphone;
}
}