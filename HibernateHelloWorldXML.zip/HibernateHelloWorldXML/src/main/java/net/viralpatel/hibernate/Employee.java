package net.viralpatel.hibernate;

public class Employee {
	private Long employeeId;

	private String firstname;


	private Department department;

	public Employee() {
	}

	public Employee(String firstname) {
		this.firstname = firstname;
		
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}
	
	

}
