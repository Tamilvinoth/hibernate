package net.viralpatel.hibernate;
import org.hibernate.SessionFactory;
import org.hibernate.Session;

public class Main {

    public static void main(String[] args) {
    	 
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session session = sf.openSession();
        session.beginTransaction();
 
        Department department = new Department();
        department.setDepartmentName("Purchase");
        session.save(department);
 
        Employee emp1 = new Employee("Arun");
        Employee emp2 = new Employee("Albert");
 
        emp1.setDepartment(department);
        emp2.setDepartment(department);
 
        session.save(emp1);
        session.save(emp2);
 
        session.getTransaction().commit();
        session.close();
    }
}
