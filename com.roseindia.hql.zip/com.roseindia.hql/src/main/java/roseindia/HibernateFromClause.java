package roseindia;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class HibernateFromClause {
private static SessionFactory sessionFactory;
private static ServiceRegistry serviceRegistry;

public static void main(String args[]) {
Session session = null;
try {
try {

sessionFactory = HibernateUtil.getSessionFactory();

} catch (Throwable th) {
System.err.println("Failed to create sessionFactory object." + th);
throw new ExceptionInInitializerError(th);
}
session = sessionFactory.openSession();
Query fromClause = session.createQuery("from Employee");
List<Employee> empList = fromClause.list();
for (Employee emp : empList) {
System.out.println("Id : " + emp.getId());
System.out.println("Name : " + emp.getName());
}
} catch (Exception e) {
System.out.println(e.getMessage());
} finally {
session.close();
}
}
}